CREATE TABLE test (id INT);
